<!DOCTYPE html>
<html>
<head>
    <title>Quản lý tiêm chủng</title>
</head>
<body>
    <h1>{{ $details['title'] }}</h1>
    <p>{{ $details['body'] }}</p>
    <a href="http://127.0.0.1:8000/"> Đến trang chủ</a>
    <p>Thank you</p>
</body>
</html>