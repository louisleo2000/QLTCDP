<?php

namespace App\DataTables;

use App\Models\Parents;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Yajra\DataTables\DataTablesEditor;

class ParentDataTableEditor extends DataTablesEditor
{
    protected $model = Parents::class;

    /**
     * Get create action validation rules.
     *
     * @return array
     */
    public function createRules()
    {
        return [
            'user.email' => 'required|email|unique:users,email',
            'user.name'  => 'required',
            'user.password' => 'required|min:8',
            'citizen_id'  => 'nullable|max:12|min:9|unique:parents|regex:/^[0-9]*$/',
            'img'  => 'nullable|max:255',
            'adress'  => 'nullable|max:255|min:5|regex:/^[A-Za-z0-9\.\-\s\,]*$/',
        ];
    }
    public function creating(Model $model, array $data)
    {
        $user = User::create([
            'name' => $data['user']['name'],
            'email' => $data['user']['email'],
            'password' => Hash::make($data['user']['password']),
        ]);

        $model->user_id = $user->id;
        return $data;
    }
    /**
     * Get edit action validation rules.
     *
     * @param Model $model
     * @return array
     */
    public function editRules(Model $model)
    {
        return [
            // 'email' => 'sometimes|required|email|' . Rule::unique($model->getTable())->ignore($model->getKey()),
            'user.name'  => 'required|max:255',
            'tel'  => 'nullable|regex:/\(?([0-9]{3})\)?([ .-]?)([0-9]{3})\2([0-9]{4})/|max:11|min:10',
            'user.email' => 'required|email|unique:users,email,'.$model->user_id,
            'user.password' => 'nullable|min:8',
            'adress'  => 'nullable|max:255|min:5|regex:/^[A-Za-z0-9\.\-\s\,]*$/',
            'citizen_id'  => 'nullable|max:12|min:9|regex:/^[0-9]*$/|unique:parents,citizen_id,'.$model->id,
            'gender' => 'required',
            'img'  => 'nullable|max:255',
        ];
    }
    public function updating(Model $model, array $data)
    {
        $user = $model->user;
        $user->email =  $data['user']['email'];
        $user->name = $data['user']['name'];
        if($data['user']['password'] !=null)
        {
            $user->password = Hash::make($data['user']['password']);
        }
        
        $user->save();
        return $data;
    }
    /**
     * Get remove action validation rules.
     *
     * @param Model $model
     * @return array
     */
    public function removeRules(Model $model)
    {
        return [];
    }
}
