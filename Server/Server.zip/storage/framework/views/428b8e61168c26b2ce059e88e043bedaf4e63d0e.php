<?php echo e($slot); ?>

<?php /**PATH D:\Dev\Project\QLTCDP\Server\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>