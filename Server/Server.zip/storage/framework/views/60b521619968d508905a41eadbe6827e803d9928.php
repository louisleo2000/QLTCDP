<!DOCTYPE html>
<html>
<head>
    <title>Quản lý tiêm chủng</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
    <a href="http://127.0.0.1:8000/"> Đến trang chủ</a>
    <p>Thank you</p>
</body>
</html><?php /**PATH D:\Dev\Project\QLTCDP\Server\resources\views/mails/register-mail.blade.php ENDPATH**/ ?>