
<?php $__env->startSection('content'); ?>
    <div class="row mt-4">
        <div class="col-12">
            <div class="card my-4">
                <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                    <div class="bg-gradient-info shadow-info border-radius-lg pt-4 pb-3">
                        <div class="row">
                            <div class="col">
                                <h6 class="text-white text-capitalize ps-3"><?php echo e($title); ?></h6>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="card-body px-3 pb-2">
                    <div class="table-responsive p-0">
                        <?php echo e($dataTable->table(['id' => 'vaccinationdetails-table'])); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var editor = new $.fn.dataTable.Editor({
                ajax: 'vaccinationdetails',
                table: "#vaccinationdetails-table",
                display: 'bootstrap',
                fields: [{
                        label: "Tên trẻ em",
                        name: "child_id",
                        type: "select",
                        // placeholder: "Tên Vắc-xin",
                        options: [
                            <?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                {
                                    label: "<?php echo e($child->name); ?>",
                                    value: "<?php echo e($child->id); ?>"
                                },
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        ]
                    },
                    {
                        label: "Tên vắc-xin",
                        name: "vaccine_id",
                        type: "select",
                        // placeholder: "Tên Vắc-xin",
                        options: [
                            <?php $__currentLoopData = $vaccines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaccine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                {
                                    label: "<?php echo e($vaccine->name); ?>",
                                    value: "<?php echo e($vaccine->id); ?>"
                                },
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        ]
                    },
                    {
                        label: "Số lô",
                        name: "lot_number",
                        attr: {
                            type: "number"
                        }
                    },
                    {
                        label: "Số mũi điều trị",
                        name: "number_injections",
                        attr: {
                            type: "number"
                        }
                    },
                ],
                i18n: {
                    create: {
                        title: "<h4>Thêm thông tin mũi tiêm chủng</h4>",
                        button: 'Thêm',
                        submit: 'Thêm '
                    },
                    edit: {
                        title: "<h4>Sửa thông tin</h4>",
                        button: 'Sửa',
                        submit: 'Sửa'
                    },
                    remove: {
                        title: "<h4>Xóa thông tin</h4>",
                        button: "Xóa",
                        submit: 'Xóa ',
                        confirm: 'Bạn có chắc chắn muốn xóa?'
                    },
                }
            });
            // $('#schedule-table').on('click', 'tbody td:not(:first-child)', function(e) {
            //     editor.inline(this);
            // });
            <?php echo e($dataTable->generateScripts()); ?>


        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dev\Project\QLTCDP\Server\resources\views/pages/vaccination-details.blade.php ENDPATH**/ ?>